import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load the dataset
path = 'D:\\ปี4\\transactions (1).csv'
df = pd.read_csv(path)

# Group the data by 'transactionCurrencyCode' and calculate the total transaction amount
transaction_summary = df.groupby('transactionCurrencyCode')['transactionAmountUSD'].sum().reset_index()

# Check the result
print(transaction_summary)

# Plot the bar chart
plt.figure(figsize=(16.4, 6.4))
sns.barplot(x='transactionCurrencyCode', y='transactionAmountUSD', data=transaction_summary, palette='viridis')

# Set the title and labels
plt.title('Total Amount of Transactions by Currency Code')
plt.xlabel('Currency Code')
plt.ylabel('Total Transaction Amount (USD)')

# Save the bar chart as q01.png
plt.savefig('q01.png')

# Display the chart
plt.show()

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load the dataset
path = 'D:\\ปี4\\transactions (1).csv'
df = pd.read_csv(path)

# Check the first few rows of the dataframe
print(df.head())

# Filter for Mastercard (MC) transactions only
df_mc = df[df['cardType'] == 'MC']

# Group by 'shipping state' and calculate the total transaction amount for each state
df_mc_grouped = df_mc.groupby('shippingState')['transactionAmountUSD'].sum().reset_index()

# Plotting the horizontal bar chart
plt.figure(figsize=(10, 6))  # Adjust the figure size if necessary
sns.barplot(x='transactionAmountUSD', y='shippingState', data=df_mc_grouped, orient='h')

# Customize the plot
plt.title('Mastercard Transaction Amounts by shippingState')
plt.xlabel('Total Transaction Amount')
plt.ylabel('shippingState')

# Save the plot as q02.png
plt.savefig('q02.png')

# Show the plot
plt.show()

import requests
import matplotlib.pyplot as plt

# Fetch data from the API
response = requests.get('https://fakestoreapi.com/products')  # Corrected API URL
products = response.json()

# Inspect the response structure
if isinstance(products, list):
    # Extract category names (since brand may not exist)
    categories = [product.get('category', 'Unknown') for product in products]

    # Count occurrences of each category
    category_counts = {}
    for category in categories:
        category_counts[category] = category_counts.get(category, 0) + 1

    # Extract data for the pie chart
    labels = list(category_counts.keys())
    sizes = list(category_counts.values())

    # Define green color shades
    colors = plt.cm.Greens([i / float(len(labels)) for i in range(len(labels))])

    # Plot the pie chart
    plt.figure(figsize=(8, 8))
    plt.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=140)
    plt.axis('equal')  # Equal aspect ratio ensures that the pie is drawn as a circle.

    # Save the pie chart as q03.png
    plt.savefig('q03.png')

    # Display the pie chart
    plt.show()
else:
    print("Error: Unexpected API response format.")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def q04():
    # Load the dataset
    path = "D:\\ปี4\\transactions (1).csv"
    try:
        df = pd.read_csv(path)
    except FileNotFoundError:
        print("The file path is incorrect. Please make sure the file exists at the specified location.")
        return
    except pd.errors.ParserError:
        print("There was an issue reading the CSV file. Please check the file's format.")
        return

    # Filter data to include only transactions less than 1000 USD
    df_filtered = df[df['transactionAmountUSD'] < 1000]

    # Plot the histogram
    plt.figure(figsize=(10, 6))  # You can adjust the figure size if needed
    plt.hist(df_filtered['transactionAmountUSD'], bins=10, edgecolor='black', color='skyblue')

    # Set labels and title
    plt.xlabel('Transaction Amount (USD)')
    plt.ylabel('Frequency')
    plt.title('Histogram of Transaction Amounts (Less than 1000 USD)')

    # Save the histogram as q04.png
    plt.savefig('q04.png')

    # Display the histogram
    plt.show()


# Call the function
q04()
