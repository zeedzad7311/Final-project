import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load the dataset
path = 'D:\\ปี4\\transactions (1).csv'
df = pd.read_csv(path)

# Group the data by 'transactionCurrencyCode' and calculate the total transaction amount
transaction_summary = df.groupby('transactionCurrencyCode')['transactionAmountUSD'].sum().reset_index()

# Check the result
print(transaction_summary)

# Plot the bar chart
plt.figure(figsize=(16.4, 6.4))
sns.barplot(x='transactionCurrencyCode', y='transactionAmountUSD', data=transaction_summary, palette='viridis')

# Set the title and labels
plt.title('Total Amount of Transactions by Currency Code')
plt.xlabel('Currency Code')
plt.ylabel('Total Transaction Amount (USD)')

# Save the bar chart as q01.png
plt.savefig('q01.png')

# Display the chart
plt.show()