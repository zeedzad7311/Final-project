import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load the dataset
path = 'D:\\ปี4\\transactions (1).csv'
df = pd.read_csv(path)

# Check the first few rows of the dataframe
print(df.head())

# Filter for Mastercard (MC) transactions only
df_mc = df[df['cardType'] == 'MC']

# Group by 'shipping state' and calculate the total transaction amount for each state
df_mc_grouped = df_mc.groupby('shippingState')['transactionAmountUSD'].sum().reset_index()

# Plotting the horizontal bar chart
plt.figure(figsize=(10, 6))  # Adjust the figure size if necessary
sns.barplot(x='transactionAmountUSD', y='shippingState', data=df_mc_grouped, orient='h')

# Customize the plot
plt.title('Mastercard Transaction Amounts by shippingState')
plt.xlabel('Total Transaction Amount')
plt.ylabel('shippingState')

# Save the plot as q02.png
plt.savefig('q02.png')

# Show the plot
plt.show()