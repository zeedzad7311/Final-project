import requests
import matplotlib.pyplot as plt

# Fetch data from the API
response = requests.get('https://fakestoreapi.com/products')  # Corrected API URL
products = response.json()

# Inspect the response structure
if isinstance(products, list):
    # Extract category names (since brand may not exist)
    categories = [product.get('category', 'Unknown') for product in products]

    # Count occurrences of each category
    category_counts = {}
    for category in categories:
        category_counts[category] = category_counts.get(category, 0) + 1

    # Extract data for the pie chart
    labels = list(category_counts.keys())
    sizes = list(category_counts.values())

    # Define green color shades
    colors = plt.cm.Greens([i / float(len(labels)) for i in range(len(labels))])

    # Plot the pie chart
    plt.figure(figsize=(8, 8))
    plt.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=140)
    plt.axis('equal')  # Equal aspect ratio ensures that the pie is drawn as a circle.

    # Save the pie chart as q03.png
    plt.savefig('q03.png')

    # Display the pie chart
    plt.show()
else:
    print("Error: Unexpected API response format.")