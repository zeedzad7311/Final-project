import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def q04():
    # Load the dataset
    path = "D:\\ปี4\\transactions (1).csv"
    try:
        df = pd.read_csv(path)
    except FileNotFoundError:
        print("The file path is incorrect. Please make sure the file exists at the specified location.")
        return
    except pd.errors.ParserError:
        print("There was an issue reading the CSV file. Please check the file's format.")
        return

    # Filter data to include only transactions less than 1000 USD
    df_filtered = df[df['transactionAmountUSD'] < 1000]

    # Plot the histogram
    plt.figure(figsize=(10, 6))  # You can adjust the figure size if needed
    plt.hist(df_filtered['transactionAmountUSD'], bins=10, edgecolor='black', color='skyblue')

    # Set labels and title
    plt.xlabel('Transaction Amount (USD)')
    plt.ylabel('Frequency')
    plt.title('Histogram of Transaction Amounts (Less than 1000 USD)')

    # Save the histogram as q04.png
    plt.savefig('q04.png')

    # Display the histogram
    plt.show()


# Call the function
q04()
