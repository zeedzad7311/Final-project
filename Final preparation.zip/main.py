import seaborn as sns
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import requests
import yfinance as yf


